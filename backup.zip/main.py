import json
# Path setup happens automatically when src is imported (see src/__init__.py)
from src.config import Config
from src.data_loader import PDFLoader
from src.tokenizer import TextTokenizer
from src.extractor import FinancialDetective
from src.visualizer import GraphVisualizer
from src.utils import setup_logger

def main():
    # Set up the logger in the command Line
    logger = setup_logger()
    logger.info("Starting The Financial Detective...")

    # 1. Fetch Data (from local file)
    loader = PDFLoader()
    raw_text = loader.fetch_messy_text()

    logger.info(f"Raw text processed successfully")

    # 2. Tokenize and preprocess text
    """ In the tokenize_text if false then the raw text will 
         be used as it is the details can be save in config """
    
    tokenized_data = None
    processed_text = raw_text
    
    if Config.TOKENIZE_TEXT:
        logger.info("Tokenizing and preprocessing text...")
        
        # Initialize the tokenizer with the chunk size and overlap
        tokenizer = TextTokenizer(
            chunk_size=Config.CHUNK_SIZE,
            chunk_overlap=Config.CHUNK_OVERLAP
        )
        tokenized_data = tokenizer.tokenize(
            raw_text,
            clean=True,
            chunk=Config.CHUNK_TEXT,
            chunk_strategy=Config.CHUNK_STRATEGY
        )
        processed_text = tokenized_data['text']
        logger.info(f"Text processed: {tokenized_data['original_length']} -> {tokenized_data['processed_length']} characters")
        if Config.CHUNK_TEXT and 'chunks' in tokenized_data:
            logger.info(f"Text chunked into {tokenized_data['chunk_count']} chunks")
    else:
        logger.info("Tokenization skipped, using raw text")

    # 3. Extract Info via LLM
    detective = FinancialDetective()
    
    # If chunking is enabled and we have chunks, pass chunks to analyzer for separate processing
    if (Config.CHUNK_TEXT and 
        Config.TOKENIZE_TEXT and 
        tokenized_data and 
        'chunks' in tokenized_data and 
        len(tokenized_data['chunks']) > 1):
        logger.info(f"Using chunked processing: {tokenized_data['chunk_count']} chunks")
        graph_data = detective.analyze(processed_text, chunks=tokenized_data['chunks'])
    else:
        logger.info("Using full text processing")
        graph_data = detective.analyze(processed_text)
    
    # Log extraction results
    logger.info("Extraction complete:")
    logger.info(f"  - Entities extracted: {len(graph_data.get('entities', []))}")
    logger.info(f"  - Relationships extracted: {len(graph_data.get('relationships', []))}")
    
    # Log some sample entities and relationships for verification
    if graph_data.get('entities'):
        sample_entities = [e.get('id', 'N/A') for e in graph_data.get('entities', [])[:5]]
        logger.info(f"Sample entities: {sample_entities}")
    if graph_data.get('relationships'):
        sample_rels = []
        for r in graph_data.get('relationships', [])[:5]:
            rel_str = f"{r.get('source', 'N/A')} -> {r.get('relation', 'N/A')} -> {r.get('target', 'N/A')}"
            sample_rels.append(rel_str)
        logger.info(f"Sample relationships: {sample_rels}")

    # 4. Save JSON Output
    json_path = Config.get_output_path(Config.JSON_FILENAME)
    with open(json_path, 'w') as f:
        json.dump(graph_data, f, indent=2)
    logger.info(f"JSON data saved to {json_path}")

    # 5. Generate Visualization
    graph_path = Config.get_output_path(Config.GRAPH_FILENAME)
    GraphVisualizer.create_and_save_graph(graph_data, graph_path)
    
    logger.info("Mission Complete. Documentation and Demo required next.")

if __name__ == "__main__":
    main()