"""
Module Description
==================

This module handel all the config details 

:Author: Vivek Khillar
:Date: 2025-12-24
:Version: 1.0
"""

import os
import sys

class Config:

    # Data source - can be URL or local file path
    PDF_URL = "https://www.reliance.com/content/dam/reliance/pdf/annual-reports/2024-25/AR2024-25.pdf"
    
    # Local messy text file (extracted from PDF)
    MESSY_TEXT_FILE = "data/messy_text.txt"
    
    # LLM API URL 
    LLM_API_URL = "http://10.173.119.32:443/v1"
    LLM_MODEL_NAME = "gemma3:12b"
    MAX_TOKENS = 8192
    
    # Model Parameters (Anti-Hallucination Settings)
    temperature = 0.0  # Lower = more deterministic, less creative (0.0 = most deterministic)
    top_p = 0.1  # Nucleus sampling - lower = more focused, less random (0.1 = very focused)
    frequency_penalty = 0.3  # Penalize repetition (0.0-2.0, higher = less repetition)
    presence_penalty = 0.2  # Penalize already used tokens (0.0-2.0, higher = more diverse)

    # Output Paths
    OUTPUT_DIR = "output"
    JSON_FILENAME = "graph_output.json"
    GRAPH_FILENAME = "knowledge_graph.png"

    # Tokenization Settings
    TOKENIZE_TEXT = True  # Enable text tokenization/cleaning
    CHUNK_TEXT = True  # Enable text chunking (set to True for very long texts)
    CHUNK_SIZE = 50000  # Maximum characters per chunk (increased for faster processing)
    CHUNK_OVERLAP = 500  # Characters to overlap between chunks
    CHUNK_STRATEGY = "sentence"  # Options: "sentence", "paragraph", "fixed"
    
    # Parallel Processing Settings
    MAX_PARALLEL_WORKERS = 5  # Number of chunks to process in parallel (increase for faster processing)

    @classmethod
    def get_output_path(cls, filename):
        if not os.path.exists(cls.OUTPUT_DIR):
            os.makedirs(cls.OUTPUT_DIR)
        return os.path.join(cls.OUTPUT_DIR, filename)
    