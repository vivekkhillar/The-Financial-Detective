import logging
import json
import re

logger = logging.getLogger("FinancialDetective")

def setup_logger(name="FinancialDetective"):
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

def clean_json_string(json_str):
    """
    Cleans markdown formatting and extracts JSON from LLM responses.
    
    NOTE: This function does NOT extract entities or relationships.
    All entity/relationship extraction is done 100% by the LLM in extractor.py.
    This only extracts the JSON string from the LLM's response.
    """
    if not json_str:
        return '{"entities": [], "relationships": []}'
    
    # First, try to extract from markdown code blocks
    code_block_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
    match = re.search(code_block_pattern, json_str, re.DOTALL)
    if match:
        try:
            json.loads(match.group(1))
            return match.group(1)
        except:
            pass
    
    # Try to find JSON object by looking for balanced braces
    json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
    matches = re.findall(json_pattern, json_str, re.DOTALL)
    
    # Try to find the largest valid JSON
    for match in sorted(matches, key=len, reverse=True):
        try:
            json.loads(match)
            return match
        except:
            continue
    
    # If no valid JSON found, return empty JSON object
    logger.warning(f"No valid JSON found in LLM response. First 200 chars: {json_str[:200]}")
    return '{"entities": [], "relationships": []}'