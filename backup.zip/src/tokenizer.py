"""
Tokenization Module
==================

This module handles tokenization and preprocessing of raw messy text
for better processing by the LLM model.

COMPETITION COMPLIANCE:
- ✅ Regex is ONLY used for text cleaning/preprocessing (whitespace, formatting)
- ✅ NO regex used for entity or relationship extraction
- ✅ All entity/relationship extraction is done 100% by LLM in extractor.py

:Author: Vivek Khillar
:Date: 2025-12-24
:Version: 1.0
"""

from typing import List, Dict, Optional
import re
from .utils import setup_logger
from .config import Config

logger = setup_logger()


class TextTokenizer:
    """
    Tokenizes and preprocesses raw text LLM model compatible.
    If not specify the chunk size and chunk overlap then the default values will be used.
    """
    
    def __init__(self, chunk_size: int = 4000, chunk_overlap: int = 300):
        
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize the raw text.
        All entity/relationship extraction is done by LLM only.
        """
        if not text:
            return ""
        
        logger.info("Cleaning text...")
        
        # Remove excessive whitespace
        text = re.sub(r' +', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Normalize page separators
        text = re.sub(r'---\s*PAGE\s*BREAK?\s*---?', '--- PAGE BREAK ---', text, flags=re.IGNORECASE)
        
        # Remove leading/trailing whitespace
        text = text.strip()
        
        logger.info(f"Text cleaned. Original length: {len(text)} characters")
        return text
    
    def split_into_sentences(self, text: str) -> List[str]:
        """
        Split text into sentences.
        
        Args:
            text: Input text
            
        Returns:
            List of sentences
        """
        # Split on sentence endings
        sentences = re.split(r'([.!?]+)\s+', text)
        
        # Reconstruct sentences with punctuation
        result = []
        for i in range(0, len(sentences) - 1, 2):
            if i + 1 < len(sentences):
                sentence = sentences[i] + sentences[i + 1]
                result.append(sentence.strip())
        
        # Add last sentence if exists
        if len(sentences) % 2 == 1:
            result.append(sentences[-1].strip())
        
        # Filter out empty sentences
        result = [s for s in result if s.strip()]
        
        logger.info(f"Split text into {len(result)} sentences")
        return result
    
    def chunk_text(self, text: str, strategy: str = "sentence") -> List[Dict[str, any]]:
        """
        Chunk text into smaller pieces for processing.
        
        Args:
            text: Input text to chunk
            strategy: Chunking strategy - "sentence", "paragraph", or "fixed"
            
        Returns:
            List of chunks with metadata
        """
        logger.info(f"Chunking text using '{strategy}' strategy...")
        
        if strategy == "sentence":
            return self._chunk_by_sentence(text)
        elif strategy == "paragraph":
            return self._chunk_by_paragraph(text)
        elif strategy == "fixed":
            return self._chunk_fixed_size(text)
        else:
            logger.warning(f"Unknown strategy '{strategy}', using 'sentence'")
            return self._chunk_by_sentence(text)
    
    def _chunk_by_sentence(self, text: str) -> List[Dict[str, any]]:
        """Chunk text by sentences, respecting chunk size."""
        sentences = self.split_into_sentences(text)
        chunks = []
        current_chunk = []
        current_size = 0
        
        for sentence in sentences:
            sentence_size = len(sentence)
            
            # If adding this sentence would exceed chunk size, save current chunk
            if current_size + sentence_size > self.chunk_size and current_chunk:
                chunk_text = ' '.join(current_chunk)
                chunks.append({
                    'text': chunk_text,
                    'size': len(chunk_text),
                    'sentence_count': len(current_chunk),
                    'chunk_index': len(chunks)
                })
                
                # Start new chunk with overlap (last few sentences)
                overlap_sentences = []
                overlap_size = 0
                for s in reversed(current_chunk):
                    if overlap_size + len(s) <= self.chunk_overlap:
                        overlap_sentences.insert(0, s)
                        overlap_size += len(s)
                    else:
                        break
                
                current_chunk = overlap_sentences
                current_size = overlap_size
            
            current_chunk.append(sentence)
            current_size += sentence_size + 1  # +1 for space
        
        # Add remaining chunk
        if current_chunk:
            chunk_text = ' '.join(current_chunk)
            chunks.append({
                'text': chunk_text,
                'size': len(chunk_text),
                'sentence_count': len(current_chunk),
                'chunk_index': len(chunks)
            })
        
        logger.info(f"Created {len(chunks)} chunks from {len(sentences)} sentences")
        return chunks
    
    def _chunk_by_paragraph(self, text: str) -> List[Dict[str, any]]:
        """Chunk text by paragraphs, respecting chunk size."""
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        chunks = []
        current_chunk = []
        current_size = 0
        
        for paragraph in paragraphs:
            para_size = len(paragraph)
            
            # If adding this paragraph would exceed chunk size, save current chunk
            if current_size + para_size > self.chunk_size and current_chunk:
                chunk_text = '\n\n'.join(current_chunk)
                chunks.append({
                    'text': chunk_text,
                    'size': len(chunk_text),
                    'paragraph_count': len(current_chunk),
                    'chunk_index': len(chunks)
                })
                
                # Start new chunk with overlap (last paragraph)
                current_chunk = [current_chunk[-1]] if current_chunk else []
                current_size = len(current_chunk[0]) if current_chunk else 0
            
            current_chunk.append(paragraph)
            current_size += para_size + 2  # +2 for \n\n
        
        # Add remaining chunk
        if current_chunk:
            chunk_text = '\n\n'.join(current_chunk)
            chunks.append({
                'text': chunk_text,
                'size': len(chunk_text),
                'paragraph_count': len(current_chunk),
                'chunk_index': len(chunks)
            })
        
        logger.info(f"Created {len(chunks)} chunks from {len(paragraphs)} paragraphs")
        return chunks
    
    def _chunk_fixed_size(self, text: str) -> List[Dict[str, any]]:
        """Chunk text into fixed-size pieces."""
        chunks = []
        text_length = len(text)
        
        start = 0
        chunk_index = 0
        
        while start < text_length:
            end = min(start + self.chunk_size, text_length)
            chunk_text = text[start:end]
            
            # Try to break at word boundary
            if end < text_length:
                # Look for last space or newline in the chunk
                last_space = max(
                    chunk_text.rfind(' '),
                    chunk_text.rfind('\n')
                )
                if last_space > self.chunk_size * 0.8:  # Only break if we're at least 80% through
                    chunk_text = chunk_text[:last_space]
                    end = start + last_space
            
            chunks.append({
                'text': chunk_text,
                'size': len(chunk_text),
                'chunk_index': chunk_index
            })
            
            # Move start position with overlap
            start = end - self.chunk_overlap
            chunk_index += 1
        
        logger.info(f"Created {len(chunks)} fixed-size chunks")
        return chunks
    
    def tokenize(self, text: str, clean: bool = True, chunk: bool = False, 
                 chunk_strategy: str = "sentence") -> Dict[str, any]:
        """
        Main tokenization method.
        
        Args:
            text: Raw text to tokenize
            clean: Whether to clean the text (default: True)
            chunk: Whether to chunk the text (default: False)
            chunk_strategy: Chunking strategy if chunk=True (default: "sentence")
            
        Returns:
            Dictionary with tokenized text and metadata
        """
        logger.info("Starting tokenization process...")
        
        # Find the original length of the text which is inside the messy text file
        original_length = len(text)
        
        # Clean text if requested
        if clean:
            text = self.clean_text(text)
        
        result = {
            'original_length': original_length,
            'processed_length': len(text),
            'text': text
        }
        
        # Chunk text if requested
        if chunk:
            chunks = self.chunk_text(text, strategy=chunk_strategy)
            result['chunks'] = chunks
            result['chunk_count'] = len(chunks)
            result['chunk_strategy'] = chunk_strategy
            logger.info(f"Tokenization complete: {len(chunks)} chunks created")
        else:
            logger.info("Tokenization complete: text processed without chunking")
        
        return result
    
    def get_token_count_estimate(self, text: str) -> int:
        """
        Estimate token count (rough approximation: ~4 characters per token).
        
        Args:
            text: Input text
            
        Returns:
            Estimated token count
        """
        # Rough estimate: 1 token ≈ 4 characters for English text
        return len(text) // 4

