from pathlib import Path
from .utils import setup_logger
from .config import Config

logger = setup_logger()

class PDFLoader:
    
    def __init__(self, file_path=None):
        """
        Initialize PDFLoader with local file path.
        file_path: Optional path to local text file. 
        If not provided, uses Config.MESSY_TEXT_FILE
        """
        self.file_path = file_path or Config.MESSY_TEXT_FILE

    def fetch_messy_text(self, file_path=None):
        """
        Load text from local messy text file
        Here in this function can sent the actual file path where ever 
        the text file is located.
        """
        file_path = file_path or self.file_path

        try:
            file_path = Path(file_path)
            logger.info(f"File path: {file_path}")
            
            if not file_path.exists():    
                # Logged the Error breaking into the code
                raise FileNotFoundError(f"Text file not found: {file_path}")
            
            logger.info(f"Reading messy text file from {file_path}...")
            
            """ Read the text file and return in to the text variable 
            by with open methode """

            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
            
            # Log the number of total characters in the messy text file 
            logger.info(f"Loaded {len(text)} characters from text file.")
            return text

        # If any other error will occurs then log the error    
        except Exception as e:
            logger.error(f"Error loading text file: {e}")
            raise