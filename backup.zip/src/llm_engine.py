from openai import OpenAI
from src.config import Config
from src.utils import setup_logger

logger = setup_logger()

class LLMEngine:
    
    def __init__(self):
        # Initialize OpenAI client pointing to the local server
        self.client = OpenAI(
            base_url=Config.LLM_API_URL,
            api_key="sk-placeholder" # Local servers usually ignore this
        )

    def generate_extraction(self, prompt, context_text, max_context_length=None):
        """
        Sends the text to the LLM and retrieves the raw response.
        
        Args:
            prompt: The extraction prompt
            context_text: The text to analyze
            max_context_length: Maximum characters to send (None = send all, default uses Config.MAX_TOKENS estimate)
        """
        # Estimate token limit: roughly 4 characters per token, leave room for prompt and response
        # MAX_TOKENS is for response, so we need to leave room for both prompt and response
        if max_context_length is None:
            # Conservative estimate: if MAX_TOKENS is 8192, we can send roughly 20000-25000 chars
            # But let's be safe and allow up to 30000 chars for context
            estimated_max_chars = min(30000, len(context_text))
        else:
            estimated_max_chars = min(max_context_length, len(context_text))
        
        context_to_send = context_text[:estimated_max_chars] if estimated_max_chars < len(context_text) else context_text
        
        messages = [
            {"role": "system", "content": "You are a JSON-only API. You MUST respond with ONLY valid JSON. No explanations, no markdown, no text before or after. Just pure JSON starting with { and ending with }. CRITICAL: Only extract information that is EXPLICITLY mentioned in the provided text. Do NOT invent, infer, or assume any information that is not directly stated in the text."},
            {"role": "user", "content": f"{prompt}\n\nTEXT TO ANALYZE:\n{context_to_send}"}
        ]
        
        if estimated_max_chars < len(context_text):
            logger.warning(f"Context truncated from {len(context_text)} to {estimated_max_chars} characters")

        try:
            logger.info("Sending request to LLM...")
            response = self.client.chat.completions.create(
                model=Config.LLM_MODEL_NAME,
                messages=messages,
                temperature=Config.temperature,
                top_p=Config.top_p,
                frequency_penalty=Config.frequency_penalty,
                presence_penalty=Config.presence_penalty,
                max_tokens=Config.MAX_TOKENS
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"LLM API Error: {e}")
            raise