"""
Financial Knowledge Graph Extractor
===================================

COMPETITION COMPLIANCE:
- ✅ NO REGEX USED for entity or relationship extraction
- ✅ 100% LLM-based extraction (all entities and relationships extracted by LLM)
- ✅ Valid JSON schema output
- ✅ Regex is ONLY used in utils.py and tokenizer.py for post-processing JSON string cleaning and text preprocessing (not for extraction)

All entity extraction (Company Names, Risk Factors, Dollar Amounts) and 
relationship extraction (OWNS, HAS_PROFIT, FACES_RISK, etc.) is done 
exclusively by the LLM model - no regex patterns are used for extraction.
"""

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from .llm_engine import LLMEngine
from .utils import setup_logger, clean_json_string
from .config import Config

logger = setup_logger()

class FinancialDetective:
    def __init__(self):
        self.llm = LLMEngine()

    def get_extraction_prompt(self):
        return """
        You are an expert Financial Knowledge Graph Extractor. Analyze the provided financial text and extract comprehensive entities and relationships into a structured JSON format.
        
        PRIMARY EXTRACTION PRIORITY (MUST EXTRACT):
        1. **Company Names** - ALL company names, subsidiaries, business units, divisions
        2. **Risk Factors** - ALL risk factors, challenges, threats mentioned
        3. **Dollar Amounts** - ALL financial figures (revenue, profit, assets, debt, etc.)
        4. **Ownership Relationships** - ALL ownership relationships (e.g., "Reliance Retail OWNS Hamleys")
        
        These four categories are MANDATORY and must be extracted comprehensively.
        
        CRITICAL EXTRACTION RULES:
        1. PRIMARY: Extract ALL information that is EXPLICITLY stated in the provided text
        2. SECONDARY: For well-known, publicly documented company relationships, you MAY use your knowledge to add relationships
        3. For company ownership relationships: If a company is mentioned in the text, you can add well-known subsidiaries/companies it owns
        4. Examples of acceptable knowledge-based additions:
           - If "Reliance Retail" is mentioned → you can add "Reliance Retail OWNS Hamleys" (well-known fact)
           - If "Reliance Jio" is mentioned → you can add known subsidiaries/brands it owns
           - If a major company is mentioned → you can add its well-known subsidiaries/divisions
        5. DO NOT invent financial figures, dates, or specific details not in text
        6. DO NOT add speculative or uncertain relationships
        7. Only add relationships that are widely known and publicly documented facts
        8. When adding knowledge-based relationships, mark them clearly or use standard relationship types
        
        CRITICAL FORMAT RULES:
        1. Output ONLY valid JSON - no markdown, no explanations, no text before or after
        2. Extract ALL relevant information that is explicitly mentioned: be EXTREMELY thorough and comprehensive
        3. Include detailed metadata for ALL entities - this is critical for rich information display
        4. Identify ALL relationships explicitly mentioned in the text - extract every connection
        5. Use the EXACT schema below - no variations
        6. For metadata: Include roles, descriptions, values, dates, percentages, categories, contexts - be detailed
        
        ENTITY TYPES TO EXTRACT (PRIORITY ORDER):
        
        **PRIORITY 1 - MANDATORY (MUST EXTRACT):**
        - Company: All company names, subsidiaries, joint ventures, associates, business units, divisions
          * Extract: Reliance Industries Limited, Reliance Retail, Reliance Jio, Jio Platforms, Hamleys, AJIO, etc.
          * For each company, also add well-known subsidiaries/brands they own (use knowledge if not in text)
        - Risk: Risk factors, challenges, threats, concerns mentioned (market, operational, regulatory, financial, strategic)
          * Extract: Market volatility, Regulatory changes, Currency fluctuations, Competition, Supply chain disruptions, etc.
        - Dollar Amount: All financial figures (revenue, profit, assets, debt, investments, expenses, costs, etc.) with FULL context
          * Extract: Net Profit amounts, Revenue amounts, Asset values, Debt amounts, Equity values, etc.
          * Include currency symbols (₹, $) and full context in metadata
        
        **PRIORITY 2 - IMPORTANT (EXTRACT IF MENTIONED):**
        - Person: Key personnel (CEOs, Chairmen, Directors, Founders, Executives, Board Members, Key Employees)
        - Location: Countries, cities, regions, states, districts mentioned
        - Product: Products, services, brands, offerings mentioned
        - Metric: KPIs, ratios, percentages (ROE, ROCE, debt-to-equity, growth rates, margins, etc.)
        - Subsidiary: Subsidiary companies and their relationships
        - Partnership: Joint ventures, partnerships, collaborations, alliances
        
        **PRIORITY 3 - ADDITIONAL (EXTRACT IF AVAILABLE):**
        - Framework: Standards, guidelines, certifications (GRI, ISO, ESG, sustainability frameworks, etc.)
        - Industry: Industries, sectors, business segments mentioned
        - Date: Important dates, financial years, periods mentioned
        - Award: Awards, recognitions, rankings, achievements mentioned
        - Project: Projects, initiatives, programs mentioned
        - Technology: Technologies, platforms, systems mentioned
        - Regulation: Regulations, policies, compliance requirements mentioned
        
        RELATIONSHIP TYPES TO IDENTIFY (PRIORITY ORDER):
        
        **PRIORITY 1 - MANDATORY OWNERSHIP RELATIONSHIPS:**
        - OWNS: Company ownership - **CRITICAL: Extract ALL ownership relationships**
          * Examples: "Reliance Retail OWNS Hamleys", "Reliance Industries Limited OWNS Reliance Retail"
          * If "Reliance Retail" is mentioned → Add: "Reliance Retail OWNS Hamleys", "Reliance Retail OWNS AJIO", etc.
          * If "Reliance Jio" is mentioned → Add: "Reliance Jio OWNS JioFiber", "Reliance Jio OWNS JioMart", etc.
          * **This is the MOST IMPORTANT relationship type - extract comprehensively**
        
        **PRIORITY 2 - FINANCIAL RELATIONSHIPS:**
        - HAS_REVENUE: Company has revenue amount
        - HAS_PROFIT: Company has profit amount
        - HAS_ASSET: Company has asset value
        - HAS_EQUITY: Company has equity value
        - HAS_DEBT: Company has debt amount
        - HAS_EXPORTS: Company has export value
        - HAS_CSR_CONTRIBUTION: Company has CSR contribution amount
        - HAS_EXPENSE: Company has expense amount
        - HAS_INVESTMENT: Company has investment amount
        - HAS_GROWTH: Company has growth rate/percentage
        
        **PRIORITY 3 - RISK RELATIONSHIPS:**
        - FACES_RISK: Company faces specific risk
        
        **PRIORITY 4 - OTHER RELATIONSHIPS:**
        - OPERATES: Company operates in location/industry
        - EMPLOYS: Company employs person
        - REPORTS_TO: Person reports to person/company
        - FOUNDER: Person is founder of company (e.g., Dhirubhai H. Ambani FOUNDER RIL)
        - CHAIRMAN: Person is chairman of company
        - MANAGING_DIRECTOR: Person is managing director of company
        - CEO: Person is CEO of company
        - DIRECTOR: Person is director of company
        - LOCATED_IN: Entity located in location
        - INVESTED_IN: Company invested in entity
        - PARTNERS_WITH: Company partners with company
        - SUBSIDIARY_OF: Company is subsidiary of company
        - RANKED_IN: Company ranked in ranking/list
        - FOLLOWS: Company follows framework/standard
        - USES: Company uses framework/standard/technology
        - IMPACTS: Action/entity impacts metric/amount
        - COMPETES_WITH: Company competes with company
        - ACQUIRED: Company acquired company
        - OPERATES_IN: Company operates in industry/sector
        - MANUFACTURES: Company manufactures product
        - PROVIDES: Company provides service/product
        - RECEIVED: Entity received award/recognition
        - IMPLEMENTS: Company implements project/initiative
        - COMPLIES_WITH: Company complies with regulation
        - RELATED_TO: General relationship when specific type unclear
        
        DETAILED EXTRACTION REQUIREMENTS:
        
        1. **CRITICAL: Extract ALL Company Names - HIGHEST PRIORITY**
           - Extract ALL company names mentioned: parent companies, subsidiaries, joint ventures, associates, business units
           - Extract business segment names (e.g., Reliance Retail, Reliance Jio, Reliance Petroleum, etc.)
           - Extract subsidiary company names explicitly mentioned
           - Extract acquired company names (e.g., Hamleys, AJIO, etc.)
           - Extract joint venture partner names
           - Extract brand names and business divisions
           - **PRIORITY: Focus on companies owned by or related to RIL (Reliance Industries Limited)**
           - **For each major company mentioned, add 3-5 well-known subsidiaries/brands they own**
           - **Example: If "Reliance Retail" is mentioned → Add: "Hamleys", "AJIO", "Reliance Trends", "Reliance Digital", "Reliance Fresh"**
        
        2. **CRITICAL: Extract ALL companies that RIL OWNS (from text AND well-known facts)**
           - If text mentions "RIL owns X" or "Reliance owns X" → extract OWNS relationship
           - If text mentions "subsidiary" or "subsidiaries" → extract all subsidiary names and create OWNS relationships
           - If text mentions "Reliance Retail", "Reliance Jio", "Reliance Petroleum", "Jio Platforms", etc. → extract as companies and create OWNS relationship from RIL
           - If text mentions "100% owned" or "wholly owned" → extract OWNS relationship
           - If text mentions "acquired" or "acquisition" → extract ACQUIRED relationship
           - Extract ALL business segments and divisions as separate companies if they are distinct entities
           - **IMPORTANT: For companies mentioned in text, add well-known subsidiaries they own (use your knowledge)**
           - **Example: If "Reliance Retail" is mentioned → Add "Reliance Retail OWNS Hamleys" (well-known fact)**
           - **Example: If "Reliance Jio" is mentioned → Add known brands/subsidiaries it owns**
           - **Example: If "Jio Platforms" is mentioned → Add known companies under Jio Platforms**
           - **For each major company mentioned, research and add 2-5 well-known subsidiaries/companies they own**
           - **This enriches the knowledge graph with complete ownership structures**
        
        3. **CRITICAL: Extract ALL Risk Factors - HIGH PRIORITY**
           - Extract ALL risk factors mentioned (market risks, operational risks, regulatory risks, financial risks, etc.)
           - Extract risk descriptions and categories
           - **ALWAYS create FACES_RISK relationship** linking RIL (or relevant company) to each risk factor
           - Include risk descriptions in metadata
           - Examples: "Market volatility", "Regulatory changes", "Currency fluctuations", "Competition", "Supply chain disruptions", etc.
           - **Extract every risk factor mentioned, no matter how minor**
        
        4. **CRITICAL: Extract ALL Dollar Amounts - HIGH PRIORITY**
           - Extract ALL profit amounts mentioned (Net Profit, Cash Profit, Profit After Tax, Operating Profit, etc.)
           - Extract profit figures with their context (e.g., "Net Profit: ₹81,309 crore" → entity: "₹81,309 crore", type: "Dollar Amount", metadata: "Net Profit FY 2024-25")
           - Extract ALL revenue amounts (e.g., "Revenue of ₹10,71,174 crore")
           - Extract ALL asset, debt, equity amounts with their context
           - Extract ALL expense, investment, export, CSR contribution amounts
           - **ALWAYS create HAS_PROFIT relationship** linking RIL (or relevant company) to profit amount
           - **ALWAYS create HAS_REVENUE relationship** linking company to revenue amount
           - **ALWAYS create HAS_ASSET/HAS_EQUITY/HAS_DEBT relationships** for financial amounts
           - Include financial year/period in metadata (e.g., "FY 2024-25", "Y-o-Y")
           - **PRIORITY: Extract ALL financial figures and create appropriate relationships**
           - **Extract every dollar amount mentioned, no matter how small**
        
        5. **CRITICAL: Extract relationships from metadata and descriptive text - BE AGGRESSIVE**
           - If metadata says "Founder is Dhirubhai H. Ambani" → create relationship: {"source": "Dhirubhai H. Ambani", "target": "RIL", "relation": "FOUNDER"}
           - If metadata says "Chairman and Managing Director" → create BOTH relationships: {"source": "Person", "target": "Company", "relation": "CHAIRMAN"} AND {"source": "Person", "target": "Company", "relation": "MANAGING_DIRECTOR"}
           - If metadata mentions a role (CEO, Director, Founder, etc.) → create appropriate relationship
           - If text says "Company X's revenue" or "Company X reported profit" → create HAS_REVENUE/HAS_PROFIT relationship
           - If text says "Company X operates in Location Y" → create OPERATES relationship
           - If text mentions "Company X in Location Y" → create LOCATED_IN relationship
           - If text mentions "Company X provides Service Y" → create PROVIDES relationship
           - If text mentions "Company X manufactures Product Y" → create MANUFACTURES relationship
           - If text mentions "Person X works for Company Y" → create EMPLOYS relationship
           - If text mentions "Company X follows Standard Y" → create FOLLOWS relationship
           - If text mentions "Company X uses Technology Y" → create USES relationship
           - **Link ALL entities to the main company (RIL) when contextually appropriate**
           - **Create multiple relationships per entity when multiple connections exist**
           - **Extract relationships even from implicit connections (e.g., "Company X's profit" implies HAS_PROFIT)**
        
        6. **CRITICAL: Extract ALL ownership relationships (who owns which company)**
           - If text mentions "Company A owns Company B" or "Company A is parent of Company B" → extract OWNS relationship
           - If text mentions "Company A subsidiary Company B" → extract SUBSIDIARY_OF relationship
           - If text mentions "Company A acquired Company B" → extract ACQUIRED relationship
           - If text mentions "Company A holds X% stake in Company B" → extract OWNS relationship with metadata
           - Extract ownership percentages when mentioned (e.g., "51% stake", "100% ownership")
           - Extract all subsidiaries, joint ventures, and associates mentioned
           - **PRIORITY: Focus on RIL's ownership of other companies**
        
        7. Extract ALL locations and link companies to locations with LOCATED_IN or OPERATES relationship
           - For EVERY location mentioned, create at least one LOCATED_IN or OPERATES relationship
        8. Extract ALL financial metrics and link them to companies with appropriate relationships
           - For EVERY metric (ROE, ROCE, growth rate, etc.), create IMPACTS or related relationship
        9. Extract ALL partnerships, joint ventures, and collaborations with PARTNERS_WITH relationship
           - For EVERY partnership mentioned, create PARTNERS_WITH relationship
        10. **CRITICAL: Create relationships for EVERY connection you can identify**
            - If Company A and Company B are mentioned together → consider PARTNERS_WITH or RELATED_TO
            - If Person X and Company Y are mentioned together → consider EMPLOYS, CHAIRMAN, DIRECTOR, etc.
            - If Amount X and Company Y are mentioned together → consider HAS_PROFIT, HAS_REVENUE, HAS_ASSET, etc.
            - If Risk X and Company Y are mentioned together → create FACES_RISK relationship
            - If Product X and Company Y are mentioned together → create MANUFACTURES or PROVIDES relationship
            - **Be proactive in creating relationships - don't wait for explicit statements**
            - **Aim for 15-20+ relationships minimum**
        10. Include RICH, DETAILED metadata for ALL entities: 
            - Roles, titles, designations for people
            - Business descriptions, industries, types for companies
            - Categories, descriptions, impact levels for risks
            - Types, periods, contexts for financial amounts
            - Values, percentages, periods for metrics
            - Descriptions, contexts, details for all other entities
            - Dates, financial years, ownership percentages when available
        11. **IMPORTANT: Create relationships from ANY descriptive information, not just explicit statements**
        12. **CRITICAL: Be EXTREMELY comprehensive - extract every piece of information that adds value to the knowledge graph**
            - "Founder is X" → FOUNDER relationship
            - "Chairman is X" → CHAIRMAN relationship  
            - "Revenue of Y" → HAS_REVENUE relationship
            - "Profit of Z" → HAS_PROFIT relationship
            - "Located in L" → LOCATED_IN relationship
            - "Operates in S" → OPERATES relationship
        12. Be comprehensive - extract as many entities and relationships as possible
        
        OWNERSHIP EXTRACTION PRIORITY (RIL's Companies):
        - **HIGHEST PRIORITY: Extract ALL companies owned by RIL**
        - Extract ALL subsidiaries of RIL (Reliance Retail, Reliance Jio, Jio Platforms, Reliance Petroleum, etc.)
        - Extract ALL companies acquired by RIL
        - Extract ALL joint ventures where RIL is a partner
        - Extract ALL business segments and divisions as separate companies
        - **Create OWNS relationship from RIL to each subsidiary/company it owns**
        - Extract ownership percentages in metadata when available
        - Examples:
          - "Reliance Retail" → Entity: "Reliance Retail", Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Reliance Retail", "relation": "OWNS"}
          - "Reliance Jio" → Entity: "Reliance Jio", Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Reliance Jio", "relation": "OWNS"}
          - "Reliance Retail owns 100% of Hamleys" → 
            Entity: "Hamleys" with metadata "100% owned by Reliance Retail"
            Relationship: {"source": "Reliance Retail", "target": "Hamleys", "relation": "OWNS"}
            Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Reliance Retail", "relation": "OWNS"}
        
        RISK FACTOR EXTRACTION PRIORITY:
        - Extract ALL risk factors mentioned in the text
        - Look for sections titled "Risk Factors", "Risks", "Challenges", "Threats"
        - Extract market risks, operational risks, regulatory risks, financial risks, strategic risks
        - **ALWAYS create FACES_RISK relationship from RIL to each risk factor**
        - Include risk category and description in metadata
        
        PROFIT AMOUNT EXTRACTION PRIORITY:
        - Extract ALL profit figures mentioned (Net Profit, Cash Profit, PAT, Operating Profit, etc.)
        - Look for phrases like "profit of", "net profit", "earnings", "income"
        - **ALWAYS create HAS_PROFIT relationship from RIL to profit amount**
        - Include profit type and financial year in metadata
        
        REQUIRED JSON FORMAT (output this exact structure):
        {
          "entities": [
            {
              "id": "entity_name",
              "type": "Company|Person|Location|Dollar Amount|Risk|Product|Framework|Metric|Subsidiary|Partnership",
              "metadata": "Detailed description, role, value, or context"
            }
          ],
          "relationships": [
            {
              "source": "entity_name",
              "target": "entity_name",
              "relation": "OWNS|OPERATES|EMPLOYS|REPORTS_TO|FOUNDER|CHAIRMAN|MANAGING_DIRECTOR|CEO|DIRECTOR|LOCATED_IN|FACES_RISK|HAS_REVENUE|HAS_PROFIT|HAS_ASSET|HAS_EQUITY|HAS_DEBT|HAS_EXPORTS|HAS_CSR_CONTRIBUTION|INVESTED_IN|PARTNERS_WITH|SUBSIDIARY_OF|RANKED_IN|FOLLOWS|USES|IMPACTS|COMPETES_WITH|ACQUIRED"
            }
          ]
        }
        
        CRITICAL: EXTRACT RELATIONSHIPS FROM METADATA AND DESCRIPTIVE TEXT:
        - If metadata says "Founder is Dhirubhai H. Ambani" or "Founder Chairman" → 
          Create relationship: {"source": "Dhirubhai H. Ambani", "target": "Reliance Industries Limited (RIL)", "relation": "FOUNDER"}
        - If metadata says "Chairman and Managing Director" → 
          Create relationship: {"source": "Person", "target": "RIL", "relation": "CHAIRMAN"} AND {"source": "Person", "target": "RIL", "relation": "MANAGING_DIRECTOR"}
        - If metadata says "Consolidated Total Equity" for an amount → 
          Create relationship: {"source": "RIL", "target": "Amount", "relation": "HAS_EQUITY"}
        - If metadata says "Exports" for an amount → 
          Create relationship: {"source": "RIL", "target": "Amount", "relation": "HAS_EXPORTS"}
        - If metadata says "CSR Contribution" → 
          Create relationship: {"source": "RIL", "target": "Amount", "relation": "HAS_CSR_CONTRIBUTION"}
        - If metadata says "Net Profit" or "Profit" → 
          Create relationship: {"source": "RIL", "target": "Amount", "relation": "HAS_PROFIT"}
        - **ALWAYS link entities to RIL when metadata or context indicates a relationship**
        - **Extract relationships from ANY descriptive information, not just explicit statements**
        
        EXAMPLES:
        - "Reliance Retail owns Hamleys" → 
          Entity: {"id": "Hamleys", "type": "Company", "metadata": "Owned by Reliance Retail"}
          Relationship: {"source": "Reliance Retail", "target": "Hamleys", "relation": "OWNS"}
        
        - "Founder is Dhirubhai H. Ambani" (from metadata) → 
          Entity: {"id": "Dhirubhai H. Ambani", "type": "Person", "metadata": "Founder Chairman"}
          Relationship: {"source": "Dhirubhai H. Ambani", "target": "Reliance Industries Limited (RIL)", "relation": "FOUNDER"}
        
        - "Chairman and Managing Director" (from metadata) → 
          Entity: {"id": "Mukesh D. Ambani", "type": "Person", "metadata": "Chairman and Managing Director"}
          Relationship: {"source": "Mukesh D. Ambani", "target": "Reliance Industries Limited (RIL)", "relation": "CHAIRMAN"}
          Relationship: {"source": "Mukesh D. Ambani", "target": "Reliance Industries Limited (RIL)", "relation": "MANAGING_DIRECTOR"}
        
        - "Consolidated Total Equity: ₹10,00,000 Crore" → 
          Entity: {"id": "₹10,00,000 Crore", "type": "Dollar Amount", "metadata": "Consolidated Total Equity"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "₹10,00,000 Crore", "relation": "HAS_EQUITY"}
        
        - "RIL reported revenue of ₹10,71,174 crore" → 
          Entity: {"id": "₹10,71,174 crore", "type": "Dollar Amount", "metadata": "Revenue FY 2024-25"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "₹10,71,174 crore", "relation": "HAS_REVENUE"}
        
        - "RIL faces market volatility risk" → 
          Entity: {"id": "Market Volatility", "type": "Risk", "metadata": "Market risk factor"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Market Volatility", "relation": "FACES_RISK"}
        
        - "RIL owns Reliance Retail" or "Reliance Retail is a subsidiary of RIL" → 
          Entity: {"id": "Reliance Retail", "type": "Company", "metadata": "Subsidiary of RIL"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Reliance Retail", "relation": "OWNS"}
        
        - "RIL reported Net Profit of ₹81,309 crore" → 
          Entity: {"id": "₹81,309 crore", "type": "Dollar Amount", "metadata": "Net Profit FY 2024-25"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "₹81,309 crore", "relation": "HAS_PROFIT"}
        
        - "Risk factors include regulatory changes and market volatility" → 
          Entity: {"id": "Regulatory Changes", "type": "Risk", "metadata": "Regulatory risk factor"}
          Entity: {"id": "Market Volatility", "type": "Risk", "metadata": "Market risk factor"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Regulatory Changes", "relation": "FACES_RISK"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Market Volatility", "relation": "FACES_RISK"}
        
        - "Reliance Jio, Reliance Retail, Jio Platforms are subsidiaries" → 
          Entity: {"id": "Reliance Jio", "type": "Company", "metadata": "Subsidiary of RIL"}
          Entity: {"id": "Jio Platforms", "type": "Company", "metadata": "Subsidiary of RIL"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Reliance Jio", "relation": "OWNS"}
          Relationship: {"source": "Reliance Industries Limited (RIL)", "target": "Jio Platforms", "relation": "OWNS"}
        
        CRITICAL FORMAT REQUIREMENTS - FOLLOW EXACTLY:
        - Start your response with { and end with }
        - Use "id" field for entity names (NOT "name", NOT "entity_name")
        - Use "metadata" field for descriptions (NOT "description", NOT "desc")
        - Use "source" and "target" in relationships (NOT "entity1" and "entity2", NOT "from" and "to")
        - Use "relation" field in relationships (NOT "type", NOT "relationship", NOT "rel")
        - **USE STANDARDIZED RELATION TYPES**: OWNS, HAS_PROFIT, HAS_REVENUE, HAS_EQUITY, FACES_RISK, CHAIRMAN, FOUNDER, etc.
        - DO NOT use descriptive text like "Business Segment", "Reached Consolidated Total Equity" - use standardized types like OWNS, HAS_EQUITY
        - DO NOT create separate sections like "financial_data", "financials", "awards_and_recognitions", "metrics", "metadata"
        - ALL entities MUST be in the "entities" array
        - ALL relationships MUST be in the "relationships" array
        - Extract as many entities and relationships as possible
        - Include detailed metadata for better context
        - Do not include any text, markdown, or explanations outside the JSON
        
        MANDATORY EXTRACTIONS:
        1. Extract ALL company names EXPLICITLY mentioned (Reliance Retail, Reliance Jio, Jio Platforms, etc.) as separate Company entities
        2. Extract ALL risk factors EXPLICITLY mentioned in the text as Risk entities
        3. Extract ALL profit amounts EXPLICITLY mentioned (Net Profit, Cash Profit, etc.) as Dollar Amount entities with HAS_PROFIT relationships
        4. Create OWNS relationships when ownership is EXPLICITLY stated in the text
        5. Create FACES_RISK relationships when risks are EXPLICITLY mentioned in the text
        
        KNOWLEDGE-BASED ENRICHMENT FOR COMPANY OWNERSHIP:
        - **CRITICAL: For each major company mentioned in the text, add well-known subsidiaries/companies they own**
        - Use your training knowledge to add publicly documented ownership relationships
        - Examples:
          * If "Reliance Retail" is mentioned → Add: "Hamleys", "AJIO", "Reliance Trends", "Reliance Digital", "Reliance Fresh" as companies, with OWNS relationships
          * If "Reliance Jio" is mentioned → Add: "JioFiber", "JioMart", "JioSaavn", "JioCinema" as companies, with OWNS relationships
          * If "Jio Platforms" is mentioned → Add known companies/brands under Jio Platforms
          * If "Reliance Industries Limited" is mentioned → Add major subsidiaries like "Reliance Retail", "Reliance Jio", "Reliance Petroleum", etc.
        - **For each company entity, add 3-5 well-known subsidiaries/brands/companies they own**
        - **This creates a comprehensive ownership structure even if not all details are in the PDF**
        - Only add relationships that are widely known and publicly documented
        - DO NOT add speculative or uncertain ownership relationships
        
        CRITICAL: EXTRACT MAXIMUM NUMBER OF RELATIONSHIPS (TARGET: 15-20+ relationships):
        - For EVERY financial amount extracted, create a relationship (HAS_PROFIT, HAS_REVENUE, HAS_ASSET, HAS_DEBT, HAS_EQUITY, etc.)
        - For EVERY person mentioned, create relationships (CHAIRMAN, FOUNDER, CEO, DIRECTOR, EMPLOYS, REPORTS_TO, etc.)
        - For EVERY company mentioned, create OWNS or SUBSIDIARY_OF relationship if ownership is mentioned
        - For EVERY risk mentioned, create FACES_RISK relationship
        - For EVERY location mentioned, create LOCATED_IN or OPERATES relationship
        - For EVERY product/service mentioned, create MANUFACTURES or PROVIDES relationship
        - For EVERY framework/standard mentioned, create FOLLOWS or USES relationship
        - For EVERY metric mentioned, create IMPACTS or related relationship
        - For EVERY award/recognition mentioned, create RECEIVED relationship
        - Create relationships between companies (PARTNERS_WITH, COMPETES_WITH, ACQUIRED, etc.)
        - Create relationships between people and companies (EMPLOYS, REPORTS_TO, etc.)
        - Create relationships between companies and locations (OPERATES, LOCATED_IN, etc.)
        - Create relationships between companies and products (MANUFACTURES, PROVIDES, etc.)
        - **GOAL: Extract at least 15-20 relationships minimum - be comprehensive and thorough**
        - **If you have 10 entities, you should have at least 10-15 relationships connecting them**
        - **Every entity should ideally have at least one relationship to another entity**
        
        RELATIONSHIP EXTRACTION TARGET:
        - **MINIMUM TARGET: 15-20 relationships** - be comprehensive
        - For every entity extracted, try to create at least 1-2 relationships
        - If you extract 10 entities, you should have 15-20 relationships
        - Create relationships from:
          * Direct statements: "Company A owns Company B" → OWNS
          * Possessive forms: "Company A's revenue" → HAS_REVENUE
          * Descriptive text: "Person X is Chairman" → CHAIRMAN
          * Contextual mentions: "Company A in Location B" → LOCATED_IN
          * Financial mentions: "Company A reported profit X" → HAS_PROFIT
          * Risk mentions: "Company A faces risk X" → FACES_RISK
        - **Be thorough - extract every relationship you can identify from the text**
        
        FINAL REMINDER - BALANCED EXTRACTION:
        - PRIMARY: Extract ALL information EXPLICITLY written in the provided text
        - SECONDARY: For company ownership relationships, you MAY use well-known, publicly documented facts
        - For financial figures, dates, specific amounts: ONLY use what's in the text
        - For company ownership structures: You can add well-known subsidiaries/companies owned by mentioned companies
        - DO NOT add speculative, uncertain, or controversial relationships
        - DO NOT invent financial data, dates, or specific business details
        - DO extract relationships from contextual clues in the text (e.g., "Company A's profit" = HAS_PROFIT)
        - When adding knowledge-based relationships, ensure they are widely recognized and documented
        - **GOAL: Enrich the graph with complete ownership structures for mentioned companies**
        - **Example: If "Reliance Retail" appears in text → Add "Hamleys", "AJIO", "Reliance Trends" as companies it owns**
        
        EXAMPLE OF CORRECT FORMAT WITH MULTIPLE RELATIONSHIPS:
        {
          "entities": [
            {"id": "Reliance Industries Limited", "type": "Company", "metadata": "India's largest private sector enterprise"},
            {"id": "Mukesh D. Ambani", "type": "Person", "metadata": "Chairman and Managing Director"},
            {"id": "₹81,309 crore", "type": "Dollar Amount", "metadata": "Net Profit FY 2024-25"},
            {"id": "₹10,71,174 crore", "type": "Dollar Amount", "metadata": "Revenue FY 2024-25"},
            {"id": "Reliance Retail", "type": "Company", "metadata": "Subsidiary of RIL"},
            {"id": "Mumbai", "type": "Location", "metadata": "Headquarters location"},
            {"id": "Market Volatility", "type": "Risk", "metadata": "Market risk factor"}
          ],
          "relationships": [
            {"source": "Mukesh D. Ambani", "target": "Reliance Industries Limited", "relation": "CHAIRMAN"},
            {"source": "Mukesh D. Ambani", "target": "Reliance Industries Limited", "relation": "MANAGING_DIRECTOR"},
            {"source": "Reliance Industries Limited", "target": "₹81,309 crore", "relation": "HAS_PROFIT"},
            {"source": "Reliance Industries Limited", "target": "₹10,71,174 crore", "relation": "HAS_REVENUE"},
            {"source": "Reliance Industries Limited", "target": "Reliance Retail", "relation": "OWNS"},
            {"source": "Reliance Industries Limited", "target": "Mumbai", "relation": "LOCATED_IN"},
            {"source": "Reliance Industries Limited", "target": "Market Volatility", "relation": "FACES_RISK"},
            {"source": "Mukesh D. Ambani", "target": "Reliance Industries Limited", "relation": "REPORTS_TO"}
          ]
        }
        
        NOTE: This example shows 8 relationships from 7 entities - aim for similar or higher relationship-to-entity ratio
        
        FINAL SUMMARY - EXTRACTION PRIORITIES (IN ORDER):
        **MUST EXTRACT (Priority Order):**
        1. **Company Names** - ALL companies mentioned + well-known subsidiaries (Hamleys, AJIO, etc.)
        2. **Ownership Relationships (OWNS)** - "Reliance Retail OWNS Hamleys" type relationships (HIGHEST PRIORITY)
        3. **Risk Factors** - ALL risks mentioned (Market volatility, Regulatory changes, etc.)
        4. **Dollar Amounts** - ALL financial figures (₹81,309 crore, ₹10,71,174 crore, etc.)
        5. **Risk Relationships (FACES_RISK)** - Link companies to risks
        6. **Financial Relationships** - HAS_PROFIT, HAS_REVENUE, HAS_ASSET, HAS_DEBT, HAS_EQUITY
        7. Other relationships and entities as available
        
        **TARGET: Extract 15-20+ relationships minimum, with STRONG FOCUS on ownership relationships (OWNS)**
        **Example ownership chain: Reliance Industries Limited OWNS Reliance Retail, Reliance Retail OWNS Hamleys, Reliance Retail OWNS AJIO**
        
        FINAL SUMMARY - EXTRACTION PRIORITIES:
        **MUST EXTRACT (in order of importance):**
        1. Company Names - ALL companies mentioned + well-known subsidiaries
        2. Ownership Relationships (OWNS) - "Reliance Retail OWNS Hamleys" type relationships
        3. Risk Factors - ALL risks mentioned
        4. Dollar Amounts - ALL financial figures with relationships (HAS_PROFIT, HAS_REVENUE, etc.)
        5. Risk Relationships (FACES_RISK) - Link companies to risks
        6. Financial Relationships (HAS_PROFIT, HAS_REVENUE, HAS_ASSET, etc.) - Link companies to amounts
        7. Other relationships and entities as available
        
        **TARGET: Extract 15-20+ relationships minimum, with focus on ownership relationships**
        """

    def analyze(self, raw_text, chunks=None):
        """
        Analyze text and extract entities/relationships.
        
        Args:
            raw_text: Full text to analyze (used if chunks is None or empty)
            chunks: Optional list of text chunks to process separately and merge
        """
        prompt = self.get_extraction_prompt()
        
        # If chunks are provided, process each chunk and merge results
        if chunks and len(chunks) > 1:
            logger.info(f"Processing {len(chunks)} chunks in parallel (max {Config.MAX_PARALLEL_WORKERS} workers)...")
            all_entities = []
            all_relationships = []
            entity_ids_seen = set()  # Track unique entity IDs to avoid duplicates
            relationships_seen = set()  # Track unique relationships
            
            def process_chunk(chunk_data_tuple):
                """Process a single chunk and return the result."""
                i, chunk = chunk_data_tuple
                try:
                    # Handle both string chunks and dict chunks (with 'text' key)
                    if isinstance(chunk, dict):
                        chunk_text = chunk.get('text', '')
                        chunk_size = chunk.get('size', len(chunk_text))
                    else:
                        chunk_text = str(chunk)
                        chunk_size = len(chunk_text)
                    
                    logger.info(f"Processing chunk {i+1}/{len(chunks)} ({chunk_size} characters)...")
                    raw_response = self.llm.generate_extraction(prompt, chunk_text, max_context_length=chunk_size)
                    
                    # Post-process the response
                    cleaned_response = clean_json_string(raw_response)
                    
                    chunk_data = json.loads(cleaned_response)
                    if "entities" not in chunk_data or "relationships" not in chunk_data:
                        logger.warning(f"Chunk {i+1} missing required keys, skipping")
                        return None, i
                    
                    logger.info(f"Chunk {i+1} extracted: {len(chunk_data.get('entities', []))} entities, {len(chunk_data.get('relationships', []))} relationships")
                    return chunk_data, i
                    
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse JSON from chunk {i+1}. Error: {e}")
                    logger.warning(f"Chunk {i+1} response preview: {raw_response[:200] if 'raw_response' in locals() else 'N/A'}...")
                    return None, i
                except Exception as e:
                    logger.error(f"Error processing chunk {i+1}: {e}")
                    return None, i
            
            # Process chunks in parallel using ThreadPoolExecutor
            # Create tuples with index and original chunk (can be dict or string)
            chunk_tuples = [(i, chunk) for i, chunk in enumerate(chunks)]
            completed = 0
            
            with ThreadPoolExecutor(max_workers=Config.MAX_PARALLEL_WORKERS) as executor:
                # Submit all chunks for processing
                future_to_chunk = {executor.submit(process_chunk, chunk_tuple): chunk_tuple[0] 
                                 for chunk_tuple in chunk_tuples}
                
                # Collect results as they complete
                for future in as_completed(future_to_chunk):
                    chunk_data, chunk_idx = future.result()
                    completed += 1
                    
                    if chunk_data is None:
                        continue
                    
                    # Merge entities (avoid duplicates by ID)
                    for entity in chunk_data.get("entities", []):
                        entity_id = entity.get("id") or entity.get("name")
                        if entity_id and entity_id not in entity_ids_seen:
                            all_entities.append(entity)
                            entity_ids_seen.add(entity_id)
                    
                    # Merge relationships (avoid exact duplicates)
                    for rel in chunk_data.get("relationships", []):
                        source = rel.get("source") or rel.get("entity1")
                        target = rel.get("target") or rel.get("entity2")
                        relation = rel.get("relation") or rel.get("type") or "RELATED_TO"
                        rel_key = (source, target, relation)
                        if rel_key not in relationships_seen:
                            all_relationships.append(rel)
                            relationships_seen.add(rel_key)
                    
                    logger.info(f"Progress: {completed}/{len(chunks)} chunks completed")
            
            logger.info(f"Merged results: {len(all_entities)} unique entities, {len(all_relationships)} unique relationships")
            return {"entities": all_entities, "relationships": all_relationships}
        
        else:
            # Process full text (or single chunk) as before
            logger.info(f"Processing full text ({len(raw_text)} characters)...")
            raw_response = self.llm.generate_extraction(prompt, raw_text)
            
            # Post-process the response
            cleaned_response = clean_json_string(raw_response)
            
            try:
                data = json.loads(cleaned_response)
                # Basic validation
                if "entities" not in data or "relationships" not in data:
                    logger.warning("JSON missing required keys, using empty structure")
                    return {"entities": [], "relationships": []}
                return data
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse JSON. LLM returned: {raw_response[:200]}...")
                logger.warning("Returning empty knowledge graph structure")
                # Return empty structure instead of crashing
                return {"entities": [], "relationships": []}